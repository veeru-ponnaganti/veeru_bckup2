#!/bin/bash
INTA=$1
INTB=$2
if [ $INTA == $INTB ]
then 
echo "$1"
else 
echo "$2"
fi
