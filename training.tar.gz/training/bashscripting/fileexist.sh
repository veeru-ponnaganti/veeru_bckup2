#!/bin/bash
# to show dir exists or not
if [ -e $1 ]
then 
echo "file exists"
else 
echo "not exist"
fi
