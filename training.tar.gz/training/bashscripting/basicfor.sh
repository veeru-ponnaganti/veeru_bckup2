#!/bin/bash
# to display for loop
#for RAM in {1..5}
#do 
#echo "$RAM"
#done
#for var in hjj if.sh
#do 
#cat $var
#done
for output in $(ls) 
do 
cat $output 

done

