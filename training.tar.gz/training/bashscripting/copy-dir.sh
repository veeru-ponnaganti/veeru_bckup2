#!/bin/bash
ntA=1
floatB=4.56
dir="/training"
# prints the value of A
echo "value of integer A is $ntA"
# print the path of the training
echo " directory path $dir"
# prints the content of dir
 pwd


