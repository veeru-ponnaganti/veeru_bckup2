#!/bin/bash
echo 'enter the name year'
read name year
echo "your name is $name"
echo "this year is $year"
