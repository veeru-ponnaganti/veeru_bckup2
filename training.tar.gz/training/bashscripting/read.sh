#!/bin/bash
#to read the user name and the password
read -p 'user name:' uservar
read  -sp 'passwd:' passvar 
echo
echo "thank you $passvar"
