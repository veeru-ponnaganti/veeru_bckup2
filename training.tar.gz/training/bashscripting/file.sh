#!/bin/bash
#A sample script
echo "hello world"
#Asimple copy script
cp $1 $2
#lets verify the copy worked or not
echo detail for the $2 
ls -lh $2
