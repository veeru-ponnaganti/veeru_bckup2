#!/bin/bash
if [ $1 -gt  2 ]
then
echo "greater than 2 "
else 
echo "less than 2 "
fi
ls
