#!/bin/bash

echo "Enter the packages you want to install saparated by a space"

read PACKAGE1 PACKAGE2 PACKAGE3

sudo apt-get install $PACKAGE1 $PACKAGE2 $PACKAGE3
echo"completed installation of packages"
